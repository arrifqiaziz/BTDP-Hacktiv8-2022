Nama			: Arrifqi Aziz Ardhiansyah
No Pesera 		: 095053
Kode Peserta 	: JVSB001ONL009
Link Github		: https://github.com/arrifqiaziz/

Penjelasan soal nomor 5

- Pertama pendeklasarian variabel
- Lalu pengisian data array dari barang, harga, dan diskon yang sudah diketahui di soal
- Menu Utama, barang ditampilkan
- User menginput ingin membeli berapa jenis barang (1-5)
- User menginput kode barang (1-5) dan kuantitas membelinya
- Kode barang yang diinput masuk kedalam array kode
- Kuantitas yang diinput masuk kedalam array qty
- Menghitung subTotal dengan rumus = (( harga - (harga * diskon)) *qty), lalu dimasukan kedalam array sub
- Menghitung Total Bayar dengan menjumlahkan semua array sub
- Output