package com.toko.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.toko.api.model.Barang;

public interface BarangRepository extends JpaRepository<Barang, Integer>{

}
