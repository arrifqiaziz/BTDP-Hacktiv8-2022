Nama			: Arrifqi Aziz Ardhiansyah
No Pesera 		: 095053
Kode Peserta 	: JVSB001ONL009
Link Github		: https://github.com/arrifqiaziz/

Assesment 3 - API

Link API -> http://localhost:8086/api/v1/barangs

list table:
namaBarang
hargaBeli
hargaJual

